export default function Home() {
  return (
    <main style={{fontFamily:'Arial, sans-serif', background:'#000', color:'white', minHeight:'100vh'}}>
      <section style={{padding:'80px 20px', textAlign:'center'}}>
        <h1 style={{fontSize:'56px', marginBottom:'20px'}}>Marc Harris Golf</h1>
        <h2 style={{fontSize:'32px', color:'#22c55e'}}>Worldwide Online Golf Coaching</h2>
        <p style={{maxWidth:'800px', margin:'30px auto', fontSize:'20px', lineHeight:'1.7'}}>
          Personalized online golf coaching, swing analysis, Zoom lessons,
          coaching packages, multilingual support, and premium worldwide golf development.
        </p>

        <div style={{display:'flex', gap:'20px', justifyContent:'center', flexWrap:'wrap'}}>
          <button style={{background:'#22c55e', color:'white', border:'none', padding:'16px 30px', borderRadius:'12px', fontSize:'18px'}}>
            Book A Lesson
          </button>

          <button style={{background:'transparent', color:'white', border:'1px solid white', padding:'16px 30px', borderRadius:'12px', fontSize:'18px'}}>
            Send Swing Video
          </button>
        </div>
      </section>

      <section style={{padding:'60px 20px', background:'#111'}}>
        <h2 style={{textAlign:'center', fontSize:'42px'}}>Coaching Programs</h2>

        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(250px,1fr))', gap:'20px', marginTop:'40px'}}>
          {['Beginner Program', 'Performance Coaching', 'Elite Coaching'].map((item, i) => (
            <div key={i} style={{background:'#1f1f1f', padding:'30px', borderRadius:'20px'}}>
              <h3 style={{fontSize:'28px'}}>{item}</h3>
              <p style={{marginTop:'20px', lineHeight:'1.7'}}>
                Premium online coaching with swing analysis, Zoom lessons, and progress tracking.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section style={{padding:'60px 20px'}}>
        <h2 style={{textAlign:'center', fontSize:'42px'}}>Global Language Support</h2>

        <div style={{marginTop:'30px', textAlign:'center'}}>
          <select style={{padding:'16px', borderRadius:'12px', fontSize:'18px'}}>
            <option>English</option>
            <option>Tiếng Việt</option>
            <option>한국어</option>
            <option>中文</option>
            <option>日本語</option>
            <option>Español</option>
            <option>Français</option>
          </select>
        </div>
      </section>

      <section style={{padding:'60px 20px', background:'#111'}}>
        <h2 style={{textAlign:'center', fontSize:'42px'}}>Contact Marc</h2>

        <div style={{textAlign:'center', marginTop:'30px', lineHeight:'2'}}>
          <p>WhatsApp: 0776326949</p>
          <p>Zalo: 0816059110</p>
        </div>
      </section>
    </main>
  )
}
